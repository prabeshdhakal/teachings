# Dataset:  biodiesel_transest.csv

* Link source: http://users.stat.ufl.edu/~winner/datasets.html

## Source: 

R.D. Micic, M.D. Tomic, F.E. Kiss, E.B. Nikolic-Djoric, M.D. Simikic
(2014). "Influence of Reaction Conditions and Type of Alcohol on Biodiesel
Yields and Process Economics of Supercritical Transesterification,"
Energy Conversion and Management, Vol. 86, pp. 717-726.

## Description: 

Experimental Results involving transesterification of rapeseed
oil in 3 alcohols (methanol, ethanol, and 1-propanol). Three factors were
varied: temperature (250, 300, 350C), pressure (8, 10, 12 MPa),
and time (7,15,20,...,60,65 min). Yields of each alcohol type (%)
and Energy consumption of each alcohol type (kW h/kg) were reported.

## Variable/column Names
    - run_id 
    - b_temp
    - b_press
    - b_time
    - meth_pct
    - meth_ec
    - eth_pct
    - eth_ec
    - prop1_pct
    - prop1_ec
